#include "stdafx.h"
#include "enumeration.h"
