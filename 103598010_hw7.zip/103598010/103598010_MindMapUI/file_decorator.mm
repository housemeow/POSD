0 "Computer" 2 7,Rectangle 
1 "windows" 5 6,Rectangle 
2 "OS" 1 3 4,Ellipse Triangle Rectangle Rectangle 
3 "IOS",Rectangle 
4 "Linux",Rectangle 
5 "DirectX",Rectangle 
6 "Microsoft Office",Rectangle 
7 "Network" 8 9,Rectangle 
8 "Wireless",Rectangle 
9 "Cable",Rectangle 
