#include "stdafx.h"
#include "i_graphics.h"


IGraphics::IGraphics()
{
}


IGraphics::~IGraphics()
{
}
