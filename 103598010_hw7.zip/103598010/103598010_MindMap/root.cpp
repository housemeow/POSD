#include "stdafx.h"
#include "root.h"

Root::Root(int id) : Composite(id)
{
}

Root::~Root()
{
}

// Root�L�k�s�W�{�`�I
void Root::addSibling(Component* component, Component* insertPosition)
{
    throw exception("Root can't insert sibling node");
}

// Root�L�k�s�W���`�I
void Root::addParent(Component* component)
{
    throw exception("Root can't insert parent node");
}

// ���oRoot���W��
string Root::getTypeName()
{
    return "Root";
}

bool Root::isAncientOf(Component* component)
{
    return true;
}

Component* Root::getMindMap()
{
    return this;
}

// visitor pattern �X��
void Root::accept(ComponentVisitor* componentVisitor)
{
    componentVisitor->visit(this);
}

Component* Root::clone()
{
    Root* newRoot = new Root(getId());
    newRoot->setDescription(getDescription());
    for (list<Component*>::iterator iterator = getNodeList().begin(); iterator != getNodeList().end(); iterator++)
        newRoot->getNodeList().push_back((*iterator)->clone());
    return newRoot;
}