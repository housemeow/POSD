#include "stdafx.h"
#include "command.h"


Command::Command()
{
}


Command::~Command()
{
}
