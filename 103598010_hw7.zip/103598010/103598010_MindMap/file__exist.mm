0 "Computer" 1 3 4
1 "windows" 2 5 6 7 8
2 "OS"
3 "OS X"
4 "Linux"
5 "DirectX"
6 "Microsoft Office"
7 "Wireless"
8 "Cable"
